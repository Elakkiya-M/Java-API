package com.modal;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="country")
public class Country {

	@Id
	private String ctycode;
	private String ctyname;
	public Country() {
		super();
	}
	public Country(String ctycode, String ctyname) {
		super();
		this.ctycode = ctycode;
		this.ctyname = ctyname;
	}
	public String getCtycode() {
		return ctycode;
	}
	public void setCtycode(String ctycode) {
		this.ctycode = ctycode;
	}
	public String getCtyname() {
		return ctyname;
	}
	public void setCtyname(String ctyname) {
		this.ctyname = ctyname;
	}
	@Override
	public String toString() {
		return "Country [ctyode=" + ctycode + ", ctyname=" + ctyname + "]";
	}
}
